import sys
import os
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module=".*pkg_resources.*")
warnings.filterwarnings("ignore", category=UserWarning, message=".*pkg_resources.*")

import pandas as pd
import psutil
import mysql.connector
import csv
from datetime import datetime, timedelta
import logging
from dotenv import load_dotenv
import platform
load_dotenv()
import time
import socket
from questionary import select
from rich import print
import subprocess
import pwd
import grp
from loguru import logger

# Performance optimization imports
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
import threading
import queue
import multiprocessing
from typing import List, Dict, Any, Optional, Tuple

# Global cache for FK lookups
_machine_fk_cache = {}
_machine_fk_lock = threading.Lock()
_config_cache_timestamp = time.time()

# Configuration from environment
BATCH_INSERT_SIZE = int(os.getenv("BATCH_INSERT_SIZE", "1000"))
ENABLE_FK_CACHING = os.getenv("ENABLE_FK_CACHING", "true").lower() == "true"
EXCEL_PROCESSING_WORKERS = int(os.getenv("EXCEL_PROCESSING_WORKERS", "4"))

# Linux-specific paths
LOG_DIRECTORY = os.getenv("LOG_DIRECTORY", "/var/log/filefinder")
TEMP_DIRECTORY = os.getenv("TEMP_DIRECTORY", "/tmp/filefinder")

# Create necessary directories
os.makedirs(LOG_DIRECTORY, exist_ok=True)
os.makedirs(TEMP_DIRECTORY, exist_ok=True)

# Environment configuration
enable_env_from_db = os.getenv("ENABLE_ENV_FROM_DB", "false").lower()

# Global configuration variables
d_file_details_file_extensions = "test"
sensitive_patterns = "test"
is_sensitive_file_extensions = "test"
enable_file_ext_count_in_scan = "test"
enable_excel_file_data_scan = "test"
enable_excel_file_data_scan_min_row = 3
n_days = 0

# Configure logging
logger.remove()
ipaddrs = None
hostname = None

try:
    ipaddrs = socket.gethostbyname(socket.gethostname())
    hostname = socket.gethostname()
    
    log_file_path = os.path.join(LOG_DIRECTORY, f"{hostname}_{ipaddrs}.log")
    logger.add(log_file_path, 
               format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
               level="INFO")
    logger.add(sys.stderr, level="ERROR")
except Exception as e:
    print(f"[yellow]Warning: Could not set up logging: {e}[/yellow]")
    logger.add(sys.stderr)

def create_db_connection(host, port, database_name, username, password):
    """Create MySQL database connection"""
    try:
        connection = mysql.connector.connect(
            host=host,
            port=port,
            database=database_name,
            user=username,
            password=password,
            autocommit=False
        )
        logger.info(f"Successfully connected to MySQL database: {database_name}")
        return connection
    except mysql.connector.Error as err:
        logger.error(f"Database connection error: {err}")
        print(f"[red]Error connecting to database: {err}[/red]")
        return None

@lru_cache(maxsize=128)
def get_or_create_machine_summary_fk(connection: Any, machine_name: str, create_if_missing: bool = True) -> Optional[int]:
    """
    Linux-optimized FK lookup with caching
    Uses Machine_Name column (schema v7.0)
    """
    global _machine_fk_cache
    
    if ENABLE_FK_CACHING and machine_name in _machine_fk_cache:
        return _machine_fk_cache[machine_name]
    
    try:
        cursor = connection.cursor()
        cursor.execute(
            "SELECT f_machine_files_summary_count_pk FROM f_machine_files_summary_count WHERE Machine_Name = %s LIMIT 1",
            (machine_name,)
        )
        result = cursor.fetchone()
        
        if result:
            fk = result[0]
            if ENABLE_FK_CACHING:
                with _machine_fk_lock:
                    _machine_fk_cache[machine_name] = fk
            return fk
        
        logger.warning(f"No FK found for Machine_Name: {machine_name}")
        return None
        
    except Exception as e:
        logger.error(f"Error in get_or_create_machine_summary_fk: {str(e)}")
        return None

def retrieve_env_values(enable_env_from_db, connection):
    """Load configuration from database or .env file"""
    if enable_env_from_db == "true":
        get_values_from_db(connection)
    else:
        get_values_from_env()

def batch_insert_file_details(connection: Any, machine_fk: int, file_batch: List[Dict], 
                              employee_username: str, start_time: float, batch_size: int = 1000) -> int:
    """
    Linux-optimized batch insert with file ownership handling
    """
    if not file_batch:
        return 0
    
    inserted_count = 0
    
    try:
        cursor = connection.cursor()
        
        # Process in chunks
        for i in range(0, len(file_batch), batch_size):
            chunk = file_batch[i:i + batch_size]
            
            values = []
            for file_data in chunk:
                truncated_path = file_data['file_path'][:759]
                
                values.append((
                    machine_fk,
                    ipaddrs,
                    hostname,
                    truncated_path,
                    file_data['file_size'],
                    file_data['file_name'],
                    file_data['file_extension'],
                    file_data['file_owner'],
                    file_data['creation_time'],
                    file_data['modification_time'],
                    file_data['access_time'],
                    file_data['is_sensitive'],
                    start_time,
                    employee_username,
                    start_time,
                    employee_username
                ))
            
            insert_query = '''
                INSERT INTO d_file_details (
                    f_machine_files_summary_count_fk, ip_address, Machine_Name, file_path, 
                    file_size_bytes, file_name, file_extension, file_owner,
                    file_creation_time, file_modification_time, file_last_access_time,
                    file_is_sensitive_data, row_creation_date_time, row_created_by,
                    row_modification_date_time, row_modification_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                         FROM_UNIXTIME(%s), %s, FROM_UNIXTIME(%s), %s)
                ON DUPLICATE KEY UPDATE
                    file_size_bytes = VALUES(file_size_bytes),
                    file_modification_time = VALUES(file_modification_time),
                    file_last_access_time = VALUES(file_last_access_time),
                    row_modification_date_time = VALUES(row_modification_date_time),
                    row_modification_by = VALUES(row_modification_by)
            '''
            
            cursor.executemany(insert_query, values)
            connection.commit()
            inserted_count += len(chunk)
            
            logger.info(f"Batch inserted {inserted_count}/{len(file_batch)} files")
        
        return inserted_count
        
    except Exception as e:
        logger.error(f"Batch insert error: {str(e)}")
        connection.rollback()
        return inserted_count

def get_values_from_db(connection):
    """Retrieve configuration from database"""
    cursor = connection.cursor()
    query = "SELECT env_key, env_value FROM env_info"
    cursor.execute(query)
    
    global config_values
    config_values = {env_key: env_value for env_key, env_value in cursor}
    
    global d_file_details_file_extensions, sensitive_patterns, is_sensitive_file_extensions
    global enable_file_ext_count_in_scan, enable_excel_file_data_scan
    global enable_excel_file_data_scan_min_row, n_days
    
    d_file_details_file_extensions = config_values.get("D_FILE_DETAILS_FILE_EXTENSIONS")
    sensitive_patterns = config_values.get("FILE_PATH_SCAN_SENSITIVE_PATTERNS")
    is_sensitive_file_extensions = config_values.get("IS_SENSITIVE_FILE_EXTENSIONS")
    enable_file_ext_count_in_scan = config_values.get("ENABLE_FILE_EXT_COUNT_IN_SCAN")
    enable_excel_file_data_scan = config_values.get("ENABLE_EXCEL_FILE_DATA_SCAN")
    enable_excel_file_data_scan_min_row = config_values.get("ENABLE_EXCEL_FILE_DATA_SCAN_MIN_ROW")
    n_days = int(config_values.get("N_DAYS", "0"))

def get_values_from_env():
    """Retrieve configuration from .env file"""
    global d_file_details_file_extensions, sensitive_patterns, is_sensitive_file_extensions
    global enable_file_ext_count_in_scan, enable_excel_file_data_scan
    global enable_excel_file_data_scan_min_row, n_days
    
    d_file_details_file_extensions = os.getenv("D_FILE_DETAILS_FILE_EXTENSIONS").split(",")
    sensitive_patterns = os.getenv("FILE_PATH_SCAN_SENSITIVE_PATTERNS").split(",")
    is_sensitive_file_extensions = os.getenv("IS_SENSITIVE_FILE_EXTENSIONS").split(",")
    enable_file_ext_count_in_scan = os.getenv("ENABLE_FILE_EXT_COUNT_IN_SCAN").lower()
    enable_excel_file_data_scan = os.getenv("ENABLE_EXCEL_FILE_DATA_SCAN").lower()
    enable_excel_file_data_scan_min_row = os.getenv("ENABLE_EXCEL_FILE_DATA_SCAN_MIN_ROW")
    n_days = int(os.getenv("N_DAYS"))

def get_ip_address():
    """Get Linux IP address"""
    try:
        result = subprocess.run(['hostname', '-I'], capture_output=True, text=True)
        ip_addresses = result.stdout.strip().split()
        return ip_addresses[0] if ip_addresses else socket.gethostbyname(socket.gethostname())
    except Exception as e:
        logger.error(f"Error getting IP address: {e}")
        return socket.gethostbyname(socket.gethostname())

def get_mount_points():
    """Get all mounted filesystems (Linux equivalent of drives)"""
    mount_points = []
    try:
        partitions = psutil.disk_partitions(all=False)
        for partition in partitions:
            # Skip virtual filesystems
            if partition.fstype in ['tmpfs', 'devtmpfs', 'squashfs', 'overlay']:
                continue
            mount_points.append(partition.mountpoint)
        return mount_points
    except Exception as e:
        logger.error(f"Error retrieving mount points: {str(e)}")
        return ['/']

def get_file_owner_linux(file_path: str) -> str:
    """Get file owner on Linux"""
    try:
        stat_info = os.stat(file_path)
        owner_uid = stat_info.st_uid
        owner_name = pwd.getpwuid(owner_uid).pw_name
        
        # Optionally include group
        group_gid = stat_info.st_gid
        group_name = grp.getgrgid(group_gid).gr_name
        
        return f"{owner_name}:{group_name}"
    except Exception as e:
        logger.error(f"Error getting owner for {file_path}: {e}")
        return "unknown"

def is_recently_accessed_or_modified(file_path, n_days):
    """Check if file was modified/accessed in last N days"""
    if n_days == 0:
        return True
    
    try:
        file_stats = os.stat(file_path)
        access_time = datetime.fromtimestamp(file_stats.st_atime)
        modification_time = datetime.fromtimestamp(file_stats.st_mtime)
        current_date = datetime.now()
        time_diff = timedelta(days=n_days)
        
        return (current_date - access_time <= time_diff) or (current_date - modification_time <= time_diff)
    except Exception as e:
        logger.error(f"Error checking file date {file_path}: {str(e)}")
        return False

def is_sensitive_file(file_path, sensitive_patterns):
    """Check if file contains sensitive data patterns"""
    try:
        allowed_extensions = is_sensitive_file_extensions
        if not any(file_path.lower().endswith(ext) for ext in allowed_extensions):
            return False
        
        file_name = os.path.basename(file_path).lower()
        
        for pattern in sensitive_patterns:
            if pattern in file_name:
                return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error checking file for sensitive data: {str(e)}")
        return False

def search_files(root_dir, extensions, n_days, sensitive_patterns):
    """Search for files matching criteria"""
    found_assets = []
    try:
        for foldername, subfolders, filenames in os.walk(root_dir):
            # Skip system directories
            if any(skip in foldername for skip in ['/proc', '/sys', '/dev', '/run', '/snap']):
                continue
            
            for filename in filenames:
                try:
                    if d_file_details_file_extensions == "all":
                        file_path = os.path.join(foldername, filename)
                        if n_days > 0:
                            if is_recently_accessed_or_modified(file_path, n_days):
                                found_assets.append(file_path)
                        else:
                            found_assets.append(file_path)
                    else:
                        if any(filename.lower().endswith(ext) for ext in extensions):
                            file_path = os.path.join(foldername, filename)
                            if n_days > 0:
                                if is_recently_accessed_or_modified(file_path, n_days):
                                    found_assets.append(file_path)
                            else:
                                found_assets.append(file_path)
                except PermissionError:
                    continue
                except Exception as e:
                    logger.warning(f"Error processing {filename}: {e}")
                    continue
                    
    except Exception as e:
        logger.error(f"Error scanning files: {str(e)}")
    
    return found_assets

def collect_file_metadata(file_path: str, sensitive_patterns: List[str]) -> Optional[Dict[str, Any]]:
    """Collect file metadata (Linux-optimized)"""
    try:
        owner_name = get_file_owner_linux(file_path)
        
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)
        file_extension = os.path.splitext(file_name)[1]
        modification_time = datetime.fromtimestamp(os.path.getmtime(file_path))
        access_time = datetime.fromtimestamp(os.path.getatime(file_path))
        creation_time = datetime.fromtimestamp(os.path.getctime(file_path))
        file_is_sensitive_data = is_sensitive_file(file_path, sensitive_patterns)
        
        return {
            'file_path': file_path,
            'file_size': file_size,
            'file_name': file_name,
            'file_extension': file_extension,
            'file_owner': owner_name,
            'creation_time': creation_time,
            'modification_time': modification_time,
            'access_time': access_time,
            'is_sensitive': '1' if file_is_sensitive_data else '0'
        }
        
    except Exception as e:
        logger.error(f"Error collecting metadata for {file_path}: {str(e)}")
        return None

def count_all_files(directory):
    """Count all files in directory"""
    try:
        total_files = 0
        for root, _, files in os.walk(directory):
            # Skip system directories
            if any(skip in root for skip in ['/proc', '/sys', '/dev', '/run', '/snap']):
                continue
            total_files += len(files)
        return total_files
    except Exception as e:
        logger.error(f"Counting all files: {str(e)}")
        return 0

def count_files_with_extension(directory, extension):
    """Count files with specific extension"""
    try:
        count = 0
        for root, dirs, files in os.walk(directory):
            if any(skip in root for skip in ['/proc', '/sys', '/dev', '/run', '/snap']):
                continue
            for file in files:
                if file.lower().endswith(extension.lower()):
                    count += 1
        return count
    except Exception as e:
        logger.error(f"Counting files with extensions: {str(e)}")
        return 0

def insert_f_machine_files_summary_count_linux(connection, ipaddress, machine_name, os_name, 
                                               os_version, system_info, employee_username, start_time):
    """Insert machine summary for Linux with disk space tracking (schema v7.0)"""
    try:
        mount_points = get_mount_points()
        mount_points_str = ", ".join(mount_points)
        num_drives = len(mount_points)
        
        # Calculate total disk space across all mount points
        total_diskspace_gb = 0.0
        used_diskspace_gb = 0.0
        free_diskspace_gb = 0.0
        
        for mount in mount_points:
            try:
                usage = psutil.disk_usage(mount)
                total_diskspace_gb += usage.total / (1024**3)  # Convert to GB
                used_diskspace_gb += usage.used / (1024**3)
                free_diskspace_gb += usage.free / (1024**3)
            except Exception as e:
                logger.warning(f"Could not get disk usage for {mount}: {e}")
        
        total_files = 0
        total_n_xls = 0
        total_n_xlsx = 0
        total_n_doc = 0
        total_n_docx = 0
        total_n_pdf = 0
        total_n_zip = 0
        total_n_sql = 0
        total_n_bak = 0
        total_n_csv = 0
        total_n_txt = 0
        total_n_jpg = 0
        total_n_psd = 0
        total_n_mp4 = 0
        total_n_png = 0
        total_n_dll = 0
        total_n_exe = 0
        total_n_tif = 0
        total_n_avi = 0
        total_n_pst = 0
        total_n_log = 0
        
        # Count files on root filesystem
        total_files = count_all_files("/")
        
        if enable_file_ext_count_in_scan.lower() == "true":
            total_n_xls = count_files_with_extension("/", ".xls")
            total_n_xlsx = count_files_with_extension("/", ".xlsx")
            total_n_doc = count_files_with_extension("/", ".doc")
            total_n_docx = count_files_with_extension("/", ".docx")
            total_n_pdf = count_files_with_extension("/", ".pdf")
            total_n_zip = count_files_with_extension("/", ".zip")
            total_n_sql = count_files_with_extension("/", ".sql")
            total_n_bak = count_files_with_extension("/", ".bak")
            total_n_csv = count_files_with_extension("/", ".csv")
            total_n_txt = count_files_with_extension("/", ".txt")
            total_n_jpg = count_files_with_extension("/", ".jpg")
            total_n_psd = count_files_with_extension("/", ".psd")
            total_n_mp4 = count_files_with_extension("/", ".mp4")
            total_n_png = count_files_with_extension("/", ".png")
            total_n_log = count_files_with_extension("/", ".log")
        
        cursor = connection.cursor()
        system_info_str = " ".join(str(info) for info in system_info)
        system_info_str = system_info_str[:255]
        
        cursor.execute('''
            INSERT INTO f_machine_files_summary_count (
                Machine_Name, ip_address, os_name, os_version, system_info,
                number_of_drives, name_of_drives,
                total_diskspace, used_diskspace, free_diskspace,
                total_n_files, total_n_xls, total_n_xlsx, total_n_doc, total_n_docx,
                total_n_pdf, total_n_zip, total_n_sql, total_n_bak, total_n_csv,
                total_n_txt, total_n_jpg, total_n_psd, total_n_mp4, total_n_png,
                total_n_dll, total_n_exe, total_n_tif, total_n_avi, total_n_pst, total_n_log,
                row_creation_date_time, row_created_by, row_modification_date_time, row_modification_by
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                FROM_UNIXTIME(%s), %s, FROM_UNIXTIME(%s), %s
            ) ON DUPLICATE KEY UPDATE
                total_diskspace=VALUES(total_diskspace),
                used_diskspace=VALUES(used_diskspace),
                free_diskspace=VALUES(free_diskspace),
                total_n_files=VALUES(total_n_files),
                total_n_xls=VALUES(total_n_xls),
                total_n_xlsx=VALUES(total_n_xlsx),
                total_n_doc=VALUES(total_n_doc),
                total_n_docx=VALUES(total_n_docx),
                total_n_pdf=VALUES(total_n_pdf),
                total_n_zip=VALUES(total_n_zip),
                total_n_sql=VALUES(total_n_sql),
                total_n_bak=VALUES(total_n_bak),
                total_n_csv=VALUES(total_n_csv),
                total_n_txt=VALUES(total_n_txt),
                total_n_jpg=VALUES(total_n_jpg),
                total_n_psd=VALUES(total_n_psd),
                total_n_mp4=VALUES(total_n_mp4),
                total_n_png=VALUES(total_n_png),
                total_n_dll=VALUES(total_n_dll),
                total_n_exe=VALUES(total_n_exe),
                total_n_tif=VALUES(total_n_tif),
                total_n_avi=VALUES(total_n_avi),
                total_n_pst=VALUES(total_n_pst),
                total_n_log=VALUES(total_n_log),
                row_modification_date_time=FROM_UNIXTIME(%s),
                row_modification_by=%s
        ''', (
            machine_name, ipaddress, os_name, os_version, system_info_str,
            num_drives, mount_points_str,
            round(total_diskspace_gb, 2), round(used_diskspace_gb, 2), round(free_diskspace_gb, 2),
            total_files, total_n_xls, total_n_xlsx, total_n_doc, total_n_docx,
            total_n_pdf, total_n_zip, total_n_sql, total_n_bak, total_n_csv,
            total_n_txt, total_n_jpg, total_n_psd, total_n_mp4, total_n_png,
            total_n_dll, total_n_exe, total_n_tif, total_n_avi, total_n_pst, total_n_log,
            start_time, employee_username, start_time, employee_username,
            start_time, employee_username
        ))
        
        connection.commit()
        logger.success("Machine summary count inserted successfully")
        
    except Exception as e:
        logger.error(f"Error inserting machine summary: {str(e)}")
        connection.rollback()

def create_audit_table(connection, employee_username, ip, start_time, end_time, elapsed_time, scan):
    """Create audit log entry"""
    try:
        cursor = connection.cursor()
        machine_name = socket.gethostname()
        
        # Get FK for audit_info
        fk = get_or_create_machine_summary_fk(connection, machine_name)
        
        cursor.execute('''
            INSERT INTO audit_info (
                f_machine_files_summary_count_fk, pc_ip_address, employee_username, 
                start_time, end_time, duration, activity_status, 
                row_creation_date_time, row_created_by
            ) VALUES (
                %s, %s, %s, FROM_UNIXTIME(%s), FROM_UNIXTIME(%s),
                %s, %s, FROM_UNIXTIME(%s), %s
            )
        ''', (fk, ip, employee_username, start_time, end_time,
              elapsed_time, scan, start_time, employee_username))
        
        connection.commit()
        logger.success("Audit entry created successfully")
        
    except Exception as e:
        logger.error(f"Error creating audit entry: {str(e)}")

def linux_scan(connection):
    """Main Linux scanning function"""
    start_time = time.time()
    
    try:
        mount_points = get_mount_points()
        
        print("[cyan]Mount Points Detected:[/cyan]")
        for i, mount in enumerate(mount_points, start=1):
            print(f"{i}. {mount}")
        
        scan_option_choices = ["Full System Scan", "Specific Path Scan"]
        scan_option = select("Select the type of scan:", choices=scan_option_choices).ask()
        
        found_assets = []
        
        if scan_option == "Full System Scan":
            print(f"[yellow]Performing full system scan for files modified in the last {n_days} days...[/yellow]")
            print("This may take several hours depending on system size.")
            logger.info("Starting full system scan")
            
            found_assets = search_files("/", d_file_details_file_extensions, n_days, sensitive_patterns)
            print(f"[bright_green]Scan complete! Found {len(found_assets)} files[/bright_green]")
            
        elif scan_option == "Specific Path Scan":
            path_choice = input("Enter the path to scan (e.g., /home/username): ")
            if os.path.exists(path_choice):
                print(f"[yellow]Scanning {path_choice}...[/yellow]")
                found_assets = search_files(path_choice, d_file_details_file_extensions, n_days, sensitive_patterns)
                print(f"[bright_green]Scan complete! Found {len(found_assets)} files[/bright_green]")
            else:
                print(f"[red]Path does not exist: {path_choice}[/red]")
                return
        
        # Insert machine summary
        os_name = platform.system()
        os_version = platform.release()
        system_info = platform.uname()
        machine_name = socket.gethostname()
        
        insert_f_machine_files_summary_count_linux(
            connection, ipaddrs, machine_name, os_name, os_version, 
            system_info, employee_username, start_time
        )
        
        # Batch insert files
        if found_assets:
            machine_fk = get_or_create_machine_summary_fk(connection, machine_name)
            
            if machine_fk:
                print("[yellow]Collecting file metadata...[/yellow]")
                file_batch = []
                
                for i, asset in enumerate(found_assets, 1):
                    file_data = collect_file_metadata(asset, sensitive_patterns)
                    if file_data:
                        file_batch.append(file_data)
                    
                    if i % 1000 == 0:
                        logger.info(f"Metadata collection progress: {i}/{len(found_assets)} files")
                
                if file_batch:
                    print(f"[yellow]Inserting {len(file_batch)} files into database...[/yellow]")
                    inserted_count = batch_insert_file_details(
                        connection, machine_fk, file_batch, employee_username, start_time
                    )
                    print(f"[bright_green]✓ Inserted {inserted_count} files successfully[/bright_green]")
            
        end_time = time.time()
        elapsed_time = end_time - start_time
        create_audit_table(connection, employee_username, ipaddrs, start_time, end_time, elapsed_time, "Linux Scan")
        
        print(f"\n[bright_green]Scan completed in {elapsed_time:.2f} seconds ({elapsed_time/60:.2f} minutes)[/bright_green]")
        
    except Exception as e:
        logger.error(f"Error in Linux scan: {str(e)}")
        print(f"[red]Error during scan: {str(e)}[/red]")

if __name__ == "__main__":
    start_time = time.time()
    
    # Load environment
    load_dotenv()
    
    # Get database credentials
    host = os.getenv("MYSQL_HOST")
    port = int(os.getenv("MYSQL_PORT", "3306"))
    database_name = os.getenv("MYSQL_DATABASE")
    username = os.getenv("MYSQL_USERNAME")
    password = os.getenv("MYSQL_PASSWORD")
    enable_env_from_db = os.getenv("ENABLE_ENV_FROM_DB", "false").lower()
    
    # System information
    os_name = platform.system()
    os_version = platform.release()
    system_info = platform.uname()
    
    print("\n" + "="*60)
    print(" "*15 + "FileFinder Linux v7.0")
    print("="*60)
    print(f"System: {os_name} {os_version}")
    print(f"Hostname: {hostname}")
    print(f"IP Address: {ipaddrs}")
    print(f"Database: {database_name}")
    print("="*60 + "\n")
    
    logger.info("="*50)
    logger.info("FileFinder Linux Started")
    logger.info(f"System: {os_name} {os_version}")
    logger.info(f"Hostname: {hostname}")
    logger.info(f"Database: {database_name}")
    
    # User input
    employee_username = input("Enter your username: ")
    
    scan_choices = ["File Count", "File Data Scan"]
    scan = select("Select scan type:", choices=scan_choices).ask()
    
    # Connect to database
    connection = create_db_connection(host, port, database_name, username, password)
    
    if not connection:
        print("[red]Failed to connect to database. Exiting.[/red]")
        sys.exit(1)
    
    # Load configuration
    retrieve_env_values(enable_env_from_db, connection)
    
    # Execute scan
    if scan == "File Count":
        print("[yellow]Performing file count...[/yellow]")
        insert_f_machine_files_summary_count_linux(
            connection, ipaddrs, hostname, os_name, os_version,
            system_info, employee_username, start_time
        )
        end_time = time.time()
        create_audit_table(connection, employee_username, ipaddrs, start_time, end_time, 
                          end_time - start_time, "File Count")
        print("[bright_green]✓ File count complete[/bright_green]")
        
    elif scan == "File Data Scan":
        linux_scan(connection)
    
    connection.close()
    
    end_time = time.time()
    total_time = end_time - start_time
    
    print(f"\n[bright_green]{'='*60}[/bright_green]")
    print(f"[bright_green]Total execution time: {total_time:.2f}s ({total_time/60:.2f} minutes)[/bright_green]")
    print(f"[bright_green]{'='*60}[/bright_green]\n")
    
    logger.success("FileFinder Linux completed successfully")
    logger.info(f"Total execution time: {total_time:.2f}s")
