# FileFinder User (Linux Client)

This folder contains the FileFinder scanner for Linux systems that connects to a remote MySQL server on Windows.

## Purpose

This is the **SCANNER CLIENT** component that will:
- Run on Linux machines (Kali, Ubuntu, Debian, etc.)
- Scan local Linux filesystem for files
- Send all scan data to remote MySQL server (Windows)
- Store NO data locally (except logs)

---

## Architecture

```
┌─────────────────────────┐         Network         ┌─────────────────────────┐
│   This Linux Machine    │ ─────────────────────> │   Windows MySQL Server  │
│   (FileFinder Scanner)  │     MySQL Protocol      │   (Database Storage)    │
│                         │       Port 3306         │                         │
│  • Scans files          │ <───────────────────── │  • Stores all data      │
│  • Collects metadata    │                         │  • rec_files database   │
│  • Sends to server      │                         │  • Centralized queries  │
└─────────────────────────┘                         └─────────────────────────┘
```

---

## Prerequisites

- **Linux OS**: Kali Linux, Ubuntu 20.04+, Debian 11+, RHEL 8+, CentOS 8+, Fedora 35+
- **Python 3.11** (EXACTLY - not 3.12+)
- **Network access** to Windows MySQL server
- **MySQL server IP address** and credentials

---

## Installation Steps

### 1. Install Python 3.11

```bash
# Ubuntu/Debian/Kali
sudo apt update
sudo apt install python3.11 python3.11-venv python3.11-dev -y

# Verify
python3.11 --version
```

### 2. Install MySQL Client (for testing)

```bash
sudo apt install mysql-client -y
```

### 3. Run Setup Script

```bash
# Make executable
chmod +x setup_linux.sh

# Run installation
./setup_linux.sh
```

This will:
- Check for Python 3.11
- Create virtual environment
- Install all dependencies
- Create log directories

---

## Configuration

### 1. Get Windows Server IP Address

**On Windows server**, run:
```cmd
ipconfig
```

Note the IPv4 Address (e.g., `192.168.1.50`)

### 2. Test Connection to MySQL Server

```bash
# Test connectivity (replace with your Windows IP)
ping 192.168.1.50

# Test MySQL port
nc -zv 192.168.1.50 3306

# Test MySQL login
mysql -h 192.168.1.50 -u arungt -p
# Password: fi!ef!ndgt!23
```

If connection fails, see troubleshooting section.

### 3. Configure .env File

```bash
nano .env
```

**Update these critical lines:**
```bash
# IMPORTANT: Use Windows MySQL Server IP
MYSQL_HOST=192.168.1.50  # ← Your Windows server IP
MYSQL_PORT=3306
MYSQL_DATABASE=rec_files
MYSQL_USERNAME=arungt
MYSQL_PASSWORD=fi!ef!ndgt!23  # ← Server password

# File extensions to scan (customize as needed)
D_FILE_DETAILS_FILE_EXTENSIONS=.xlsx,.xls,.pdf,.doc,.docx,.txt

# Date filter (0=all files, N=files modified in last N days)
N_DAYS=0

# Performance settings (leave default)
BATCH_INSERT_SIZE=1000
ENABLE_FK_CACHING=true
EXCEL_PROCESSING_WORKERS=4

# Linux paths (leave default)
LOG_DIRECTORY=/var/log/filefinder
TEMP_DIRECTORY=/tmp/filefinder

# Features
ENABLE_FILE_EXT_COUNT_IN_SCAN=false
ENABLE_EXCEL_FILE_DATA_SCAN=false
ENABLE_APP_LOG_TO_DB=true

# Sensitive data detection
IS_SENSITIVE_FILE_EXTENSIONS=.xls,.xlsx,.doc,.docx,.pdf
FILE_PATH_SCAN_SENSITIVE_PATTERNS=password,creditcard,ssn,confidential
```

**Save:** `Ctrl+X`, then `Y`, then `Enter`

### 4. Secure .env File

```bash
chmod 600 .env
```

---

## Running FileFinder

### Activate Virtual Environment

```bash
source venv/bin/activate
```

Your prompt will change to: `(venv) user@machine:~/FileFinder_User_Linux$`

### Run Scanner

```bash
python file_info_version_22_linux.py
```

### Follow Prompts

1. **Enter your username**: Your name (e.g., `john`)
2. **Select scan type**:
   - `File Count` - Quick count only
   - `File Data Scan` - Full detailed scan
3. **Select scan option** (if File Data Scan):
   - `Full System Scan` - Scans all mount points (slow)
   - `Specific Path Scan` - Scans chosen directory (recommended)
4. **Enter path** (if Specific Path):
   - Example: `/home/john/Documents`

---

## Recommended First Run

```bash
source venv/bin/activate
python file_info_version_22_linux.py
```

**Selections:**
- Username: `yourusername`
- Scan type: `File Data Scan`
- Scan option: `Specific Path Scan`
- Path: `/home/yourusername/Documents`

This tests the system on a small directory first.

---

## Verify Data on Windows Server

After scanning, check data was stored on Windows:

**On Windows MySQL server:**
```sql
USE rec_files;

-- Check if this Linux machine appears
SELECT hostname, ip_address, total_n_files, row_creation_date_time
FROM f_machine_files_summary_count
ORDER BY row_creation_date_time DESC;

-- Check file details from this machine
SELECT COUNT(*) FROM d_file_details WHERE hostname = 'your-linux-hostname';

-- View recent files scanned
SELECT file_path, file_size_bytes, file_modification_time
FROM d_file_details
WHERE hostname = 'your-linux-hostname'
ORDER BY row_creation_date_time DESC
LIMIT 10;
```

You should see Linux file paths like:
- `/home/user/Documents/file.pdf`
- `/opt/data/document.xlsx`

---

## Running Regular Scans

### Manual Scans

```bash
cd ~/FileFinder_User_Linux
source venv/bin/activate
python file_info_version_22_linux.py
```

### Automated Scans (Optional - Systemd)

**For scheduled scans, see:** `SYSTEMD_SETUP.md`

Quick setup:
```bash
# Edit service file with your username and paths
sudo nano filefinder.service

# Copy to systemd
sudo cp filefinder.service /etc/systemd/system/
sudo cp filefinder.timer /etc/systemd/system/

# Enable daily scans
sudo systemctl daemon-reload
sudo systemctl enable filefinder.timer
sudo systemctl start filefinder.timer
```

---

## Troubleshooting

### "Can't connect to MySQL server"

**Check network connectivity:**
```bash
ping 192.168.1.50  # Windows server IP

# Check if port is accessible
nc -zv 192.168.1.50 3306
# Or
telnet 192.168.1.50 3306
```

**Possible causes:**
- Windows firewall blocking port 3306
- MySQL not configured for remote connections
- Wrong IP address in .env file
- Network/router blocking traffic

**Solutions:**
- On Windows: Check firewall allows port 3306
- On Windows: Verify `bind-address = 0.0.0.0` in my.ini
- On Windows: Restart MySQL service
- Check router doesn't block 3306

### "Access denied for user 'arungt'"

**Check credentials in .env:**
```bash
cat .env | grep MYSQL_
```

**Test from command line:**
```bash
mysql -h 192.168.1.50 -u arungt -p
# Enter password when prompted
```

**On Windows server, verify user:**
```sql
SELECT user, host FROM mysql.user WHERE user='arungt';
-- Should show: arungt | %
```

### "Unknown database 'rec_files'"

**On Windows server:**
```sql
SHOW DATABASES;
-- Should include rec_files
```

If missing, run database creation script on Windows:
```cmd
mysql -u root -p < SQLScripts\2rec_files.sql
```

### "Permission denied" when scanning

```bash
# For system-wide scans, use sudo
sudo -E env PATH=$PATH python file_info_version_22_linux.py

# Or scan only user-accessible directories
# Path: /home/yourusername
```

### "Log directory not writable"

```bash
sudo mkdir -p /var/log/filefinder
sudo chown $(whoami):$(whoami) /var/log/filefinder
sudo chmod 755 /var/log/filefinder
```

---

## Files in This Folder

```
FileFinder_User_Linux/
├── file_info_version_22_linux.py    # Main scanner application
├── requirements-linux.txt            # Python dependencies
├── .env                             # Configuration (edit this!)
├── pyproject.toml                   # Poetry config
├── setup_linux.sh                   # Installation script
├── .gitignore                       # Git ignore patterns
├── README_USER.md                   # This file
├── DEPLOYMENT_CHECKLIST.md          # Deployment guide
├── LINUX_MIGRATION_SUMMARY.md       # Migration notes
├── PROJECT_OVERVIEW.md              # Full overview
└── Systemd Files (optional):
    ├── filefinder.service           # Service unit
    ├── filefinder.timer             # Timer unit
    └── SYSTEMD_SETUP.md             # Automation guide
```

**Note:** SQL scripts are NOT needed on client machines (only on server)

---

## Security Notes

1. **Network Security**
   - MySQL traffic is unencrypted by default
   - Use VPN for scanning over internet
   - Restrict server firewall to known IPs

2. **Credentials**
   - `.env` file contains password
   - Ensure file permissions: `chmod 600 .env`
   - Don't commit .env to git

3. **Scan Permissions**
   - Running as regular user limits access
   - Use `sudo -E` for full system scans
   - Be aware of what data you're collecting

---

## Multiple Linux Machines

You can install this scanner on **multiple Linux machines**:
- All connect to same Windows MySQL server
- Each machine identified by hostname
- Centralized data viewing on Windows
- Each `.env` points to same `MYSQL_HOST`

---

## Support

- **Main Documentation**: `README_LINUX.md`
- **Deployment**: `DEPLOYMENT_CHECKLIST.md`
- **Server Setup**: See `FileFinder_Server_Windows` folder
- **Contact**: arunkg99@gmail.com

---

**Ready to scan! All data will be stored on your Windows MySQL server.** 🔍✨
