# 🚀 FileFinder Linux Deployment Checklist

Use this checklist to ensure proper deployment of FileFinder on Linux systems.

---

## ✅ Pre-Deployment

### System Requirements
- [ ] Linux OS: Ubuntu 20.04+, Debian 11+, RHEL 8+, CentOS 8+, or Fedora 35+
- [ ] Python 3.11 (EXACTLY) installed
- [ ] MySQL 8.0 or higher installed
- [ ] At least 2GB free disk space
- [ ] Network access to MySQL server (if remote)

### User Permissions
- [ ] User account created for FileFinder
- [ ] User has sudo access (for initial setup)
- [ ] User has read access to directories to be scanned

---

## 📦 Installation Steps

### 1. Transfer Files
```bash
# Copy FileFinder_Linux directory to server
scp -r FileFinder_Linux/ user@server:/home/user/

# Or use git clone if in repository
cd /home/user
git clone <repository-url>
cd FileFinder_Linux
```
- [ ] Files transferred successfully
- [ ] Directory structure intact

### 2. Install Python Dependencies
```bash
cd FileFinder_Linux
chmod +x setup_linux.sh
./setup_linux.sh
```
- [ ] Setup script executed successfully
- [ ] Virtual environment created
- [ ] All dependencies installed
- [ ] No error messages

### 3. Create Log Directory
```bash
sudo mkdir -p /var/log/filefinder
sudo chown $USER:$USER /var/log/filefinder
chmod 755 /var/log/filefinder
```
- [ ] Log directory created
- [ ] Proper permissions set
- [ ] User can write to directory

### 4. Create Temp Directory
```bash
mkdir -p /tmp/filefinder
chmod 755 /tmp/filefinder
```
- [ ] Temp directory created
- [ ] Proper permissions set

---

## 🗄️ Database Setup

### 1. Secure MySQL Installation
```bash
sudo mysql_secure_installation
```
- [ ] Root password set
- [ ] Anonymous users removed
- [ ] Remote root login disabled
- [ ] Test database removed

### 2. Create Database User
```bash
mysql -u root -p < SQLScripts/1mysql_user.sql
```
- [ ] User 'arungt' created
- [ ] Proper privileges granted
- [ ] Password configured

### 3. Create Database Schema
```bash
mysql -u root -p < SQLScripts/2rec_files.sql
```
- [ ] Database 'rec_files' created
- [ ] All tables created successfully
- [ ] No error messages

### 4. Create Performance Indexes
```bash
mysql -u arungt -p rec_files < SQLScripts/3_rec_performance_indexes.sql
```
- [ ] Indexes created successfully
- [ ] Query performance optimized

### 5. Test Database Connection
```bash
mysql -u arungt -p -e "USE rec_files; SHOW TABLES;"
```
- [ ] Connection successful
- [ ] All tables visible
- [ ] Expected output received

---

## ⚙️ Configuration

### 1. Edit .env File
```bash
nano .env
```

**Update these values:**
```bash
MYSQL_HOST=localhost          # Or remote host IP
MYSQL_PORT=3306
MYSQL_DATABASE=rec_files
MYSQL_USERNAME=arungt
MYSQL_PASSWORD=YourSecurePassword123!  # CHANGE THIS!

D_FILE_DETAILS_FILE_EXTENSIONS=.xlsx,.xls,.pdf,.doc,.docx,.txt
N_DAYS=0  # 0=all files, >0=modified in last N days

BATCH_INSERT_SIZE=1000
ENABLE_FK_CACHING=true
EXCEL_PROCESSING_WORKERS=4

LOG_DIRECTORY=/var/log/filefinder
TEMP_DIRECTORY=/tmp/filefinder

ENABLE_FILE_EXT_COUNT_IN_SCAN=false
ENABLE_EXCEL_FILE_DATA_SCAN=false
ENABLE_APP_LOG_TO_DB=true

IS_SENSITIVE_FILE_EXTENSIONS=.xls,.xlsx,.doc,.docx,.pdf
FILE_PATH_SCAN_SENSITIVE_PATTERNS=password,creditcard,ssn,confidential
```

- [ ] Database credentials updated
- [ ] File extensions configured
- [ ] Sensitive patterns defined
- [ ] Paths verified
- [ ] Performance settings reviewed

### 2. Secure .env File
```bash
chmod 600 .env
```
- [ ] Permissions restricted to owner only

---

## 🧪 Testing

### 1. Test Virtual Environment
```bash
source venv/bin/activate
python --version  # Should be 3.11.x
```
- [ ] Virtual environment activates
- [ ] Python version is 3.11.x (not 3.12 or higher)

### 2. Test Python Script
```bash
python3 file_info_version_22_linux.py --help 2>/dev/null || echo "Script loads successfully"
```
- [ ] Script loads without errors
- [ ] No import errors

### 3. Test Database Connection
```bash
source venv/bin/activate
python3 -c "from file_info_version_22_linux import create_db_connection; import os; from dotenv import load_dotenv; load_dotenv(); conn = create_db_connection(os.getenv('MYSQL_HOST'), int(os.getenv('MYSQL_PORT')), os.getenv('MYSQL_DATABASE'), os.getenv('MYSQL_USERNAME'), os.getenv('MYSQL_PASSWORD')); print('✓ Connected' if conn else '✗ Failed')"
```
- [ ] Database connection successful

### 4. Test File Count Scan
```bash
# Run a quick file count test on a small directory
source venv/bin/activate
python file_info_version_22_linux.py
# When prompted:
# - Enter username: testuser
# - Select: File Count
# - Watch for success messages
```
- [ ] File count completes successfully
- [ ] Data inserted into database
- [ ] No errors in log file

### 5. Verify Database Data
```bash
mysql -u arungt -p rec_files -e "SELECT COUNT(*) FROM f_machine_files_summary_count;"
mysql -u arungt -p rec_files -e "SELECT * FROM audit_info ORDER BY start_time DESC LIMIT 1;"
```
- [ ] Machine summary record exists
- [ ] Audit record created

---

## 🔄 Systemd Automation (Optional)

### 1. Install Service Files
```bash
sudo cp filefinder.service /etc/systemd/system/
sudo cp filefinder.timer /etc/systemd/system/
```
- [ ] Service file copied
- [ ] Timer file copied

### 2. Edit Service File
```bash
sudo nano /etc/systemd/system/filefinder.service
```

**Update paths:**
```ini
User=your_username
WorkingDirectory=/home/your_username/FileFinder_Linux
ExecStart=/home/your_username/FileFinder_Linux/venv/bin/python3 /home/your_username/FileFinder_Linux/file_info_version_22_linux.py
```
- [ ] User updated
- [ ] WorkingDirectory updated
- [ ] ExecStart path updated

### 3. Reload and Enable
```bash
sudo systemctl daemon-reload
sudo systemctl enable filefinder.timer
sudo systemctl start filefinder.timer
```
- [ ] Systemd reloaded
- [ ] Timer enabled
- [ ] Timer started

### 4. Verify Timer
```bash
sudo systemctl status filefinder.timer
systemctl list-timers --all | grep filefinder
```
- [ ] Timer is active
- [ ] Next run time scheduled

---

## 🔒 Security Hardening

### 1. File Permissions
```bash
chmod 700 FileFinder_Linux
chmod 600 .env
chmod 600 *.log
```
- [ ] Directory restricted to owner
- [ ] Environment file protected
- [ ] Log files protected

### 2. Database Security
```bash
mysql -u arungt -p -e "SHOW GRANTS FOR 'arungt'@'localhost';"
```
- [ ] User has minimum required privileges
- [ ] No unnecessary GRANT ALL permissions

### 3. Log Rotation
```bash
sudo nano /etc/logrotate.d/filefinder
```

**Add:**
```
/var/log/filefinder/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    missingok
    create 0644 your_username your_username
}
```
- [ ] Log rotation configured
- [ ] Logs will be compressed after 14 days

---

## 📊 Production Deployment

### 1. Documentation
- [ ] README_LINUX.md reviewed
- [ ] SYSTEMD_SETUP.md reviewed (if using systemd)
- [ ] Configuration documented for team

### 2. Backup Plan
- [ ] Database backup strategy defined
- [ ] .env file backed up securely
- [ ] Restore procedure documented

### 3. Monitoring
- [ ] Log monitoring configured
- [ ] Database size monitoring setup
- [ ] Disk space alerts configured

### 4. Support
- [ ] Team trained on usage
- [ ] Troubleshooting guide available
- [ ] Contact information documented

---

## 🎯 First Production Run

### 1. Choose Scan Type
```bash
source venv/bin/activate
python3 file_info_version_22_linux.py
```

**Recommendations:**
- **First Run**: Start with "File Count" scan
- **Second Run**: Test "Specific Path Scan" on small directory
- **Full Production**: "Full System Scan" (schedule during off-hours)

### 2. Monitor Progress
```bash
# In another terminal, watch logs
tail -f /var/log/filefinder/$(hostname)_*.log
```
- [ ] Scan starts successfully
- [ ] Progress logged
- [ ] No critical errors

### 3. Verify Results
```bash
mysql -u arungt -p rec_files -e "
SELECT 
    hostname,
    total_n_files,
    row_creation_date_time
FROM f_machine_files_summary_count
ORDER BY row_creation_date_time DESC
LIMIT 5;"
```
- [ ] Data inserted correctly
- [ ] Counts look reasonable
- [ ] Timestamps correct

---

## 📈 Post-Deployment

### 1. Performance Tuning
- [ ] Adjust BATCH_INSERT_SIZE if needed
- [ ] Review scan duration
- [ ] Optimize N_DAYS filter

### 2. Schedule Regular Scans
- [ ] Systemd timer configured for daily/weekly scans
- [ ] Schedule during low-usage hours
- [ ] Notifications configured

### 3. Maintenance
- [ ] Database cleanup scheduled
- [ ] Log rotation working
- [ ] Disk space monitored

---

## ✅ Deployment Complete!

**Date:** ________________  
**Deployed By:** ________________  
**Server:** ________________  
**Version:** FileFinder Linux v7.0  

---

## 📞 Support Contacts

**Technical Issues:**
- Check logs: `/var/log/filefinder/`
- Review documentation: `README_LINUX.md`
- Database logs: `mysql -u arungt -p rec_files -e "SELECT * FROM audit_info ORDER BY start_time DESC LIMIT 10;"`

**Author:**
- Arun Kumar (arunkg99@gmail.com)

---

**Congratulations! FileFinder Linux is deployed and ready for production use! 🎉**
