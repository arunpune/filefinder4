CREATE USER 'arungt'@'localhost' IDENTIFIED BY 'fi!ef!ndgt!23'; 
GRANT ALL PRIVILEGES ON *.* TO 'arungt'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES; 
SHOW GRANTS FOR 'arungt'@'localhost';
