# FileFinder Linux Edition

Linux-optimized version of FileFinder for file inventory and analysis.

## Key Linux Adaptations

### 1. **File Ownership Handling**
- Uses `pwd` and `grp` modules instead of `win32security`
- Returns owner in format: `username:groupname`
- Handles permission errors gracefully

### 2. **Filesystem Navigation**
- Scans from root (`/`) or specified mount points
- Skips system directories: `/proc`, `/sys`, `/dev`, `/run`, `/snap`
- Uses mount points instead of drive letters

### 3. **IP Address Detection**
- Uses `hostname -I` command on Linux
- Falls back to socket method if command fails

### 4. **Logging**
- Default log directory: `/var/log/filefinder`
- Create with: `sudo mkdir -p /var/log/filefinder && sudo chown $USER /var/log/filefinder`

## Installation

### Prerequisites

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install python3.11 python3.11-venv python3.11-dev mysql-server

# RHEL/CentOS/Fedora
sudo dnf install python3.11 python3.11-devel mysql-server
```

### Setup

```bash
# Make setup script executable
chmod +x setup_linux.sh

# Run setup
./setup_linux.sh
```

### Manual Setup

```bash
# Create virtual environment with Python 3.11
python3.11 -m venv venv

# Activate
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install wheel setuptools
pip install "numpy<2.0"
pip install pandas==2.1.2
pip install -r requirements-linux.txt
```

## MySQL Setup

```bash
# Secure MySQL installation
sudo mysql_secure_installation

# Create database
mysql -u root -p < SQLScripts/1mysql_user.sql
mysql -u root -p < SQLScripts/2rec_files.sql
mysql -u arungt -p rec_files < SQLScripts/3_rec_performance_indexes.sql
```

## Usage

```bash
# Activate virtual environment
source venv/bin/activate

# Run scanner
python3 file_info_version_22_linux.py
```

### Running with sudo (for system-wide scans)

```bash
# Activate venv and run with sudo
source venv/bin/activate
sudo -E env PATH=$PATH python3.11 file_info_version_22_linux.py
```

The `-E` flag preserves environment variables including the virtual environment path.

## Differences from Windows Version

| Feature | Windows | Linux |
|---------|---------|-------|
| **File Owner** | `win32security` | `pwd + grp` modules |
| **Drives** | Drive letters (C:\, D:\) | Mount points (/, /home, /mnt) |
| **System Dirs** | Skip based on attributes | Skip `/proc`, `/sys`, etc. |
| **IP Detection** | `socket.gethostbyname()` | `hostname -I` command |
| **Log Path** | Current directory | `/var/log/filefinder` |
| **Permissions** | Run as Administrator | Run with `sudo` for full scan |

## Performance Tips

1. **Skip system directories**: Already configured to skip `/proc`, `/sys`, etc.
2. **Use specific paths**: Scan `/home` instead of `/` for faster results
3. **Adjust batch size**: Increase `BATCH_INSERT_SIZE` for faster inserts
4. **Disable extension counting**: Set `ENABLE_FILE_EXT_COUNT_IN_SCAN=false`

## Systemd Service (Optional)

Create scheduled scans:

```bash
# Create service file
sudo nano /etc/systemd/system/filefinder.service
```

```ini
[Unit]
Description=FileFinder Scan Service
After=network.target mysql.service

[Service]
Type=oneshot
User=youruser
WorkingDirectory=/path/to/FileFinder_Linux
Environment="PATH=/path/to/FileFinder_Linux/venv/bin"
ExecStart=/path/to/FileFinder_Linux/venv/bin/python3 file_info_version_22_linux.py

[Install]
WantedBy=multi-user.target
```

```bash
# Create timer file
sudo nano /etc/systemd/system/filefinder.timer
```

```ini
[Unit]
Description=FileFinder Daily Scan Timer

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
```

```bash
# Enable and start
sudo systemctl enable filefinder.timer
sudo systemctl start filefinder.timer

# Check status
sudo systemctl status filefinder.timer
```

## Troubleshooting

### Permission Denied

```bash
# Solution 1: Run with sudo
sudo -E python3 file_info_version_22_linux.py

# Solution 2: Add user to required groups
sudo usermod -aG adm $USER
```

### MySQL Connection Failed

```bash
# Check MySQL service
sudo systemctl status mysql

# Test connection
mysql -u arungt -p -e "SHOW DATABASES;"
```

### Log Directory Permissions

```bash
# Create and set permissions
sudo mkdir -p /var/log/filefinder
sudo chown $USER:$USER /var/log/filefinder
```

## Configuration (.env file)

Edit the `.env` file to customize:

```bash
# Database settings
MYSQL_HOST=localhost
MYSQL_DATABASE=rec_files
MYSQL_USERNAME=arungt
MYSQL_PASSWORD=your_password

# File extensions to scan
D_FILE_DETAILS_FILE_EXTENSIONS=.xlsx,.xls,.pdf,.doc,.docx,.txt

# Days filter (0 = all files, >0 = modified in last N days)
N_DAYS=0

# Performance settings
BATCH_INSERT_SIZE=1000
ENABLE_FK_CACHING=true

# Logging
LOG_DIRECTORY=/var/log/filefinder
```

## Security Notes

1. **Sensitive Data**: The tool can detect files with sensitive patterns (configured in `.env`)
2. **Database Password**: Store securely in `.env` file with restricted permissions (`chmod 600 .env`)
3. **Sudo Access**: Only required for full system scans; user home scans don't need sudo
4. **Audit Trail**: All scans are logged to the `audit_info` table in MySQL

## Support

For issues, refer to:
- Main README.md in the parent directory
- MIGRATION_GUIDE.md for upgrading from Windows version
- Log files in `/var/log/filefinder/`

## License

Copyright © 2024. All rights reserved.
