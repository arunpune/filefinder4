# 🐧 FileFinder Linux Edition - Complete Project

## ✅ Project Successfully Created!

A complete Linux-optimized version of FileFinder has been created in the `FileFinder_Linux/` directory.

---

## 📁 Project Structure

```
FileFinder_Linux/
│
├── 🐍 Python Application
│   └── file_info_version_22_linux.py    # Main scanner (Linux-optimized)
│
├── 📦 Configuration Files
│   ├── requirements-linux.txt            # Python dependencies
│   ├── .env                             # Environment variables
│   ├── pyproject.toml                   # Poetry configuration
│   └── .gitignore                       # Git ignore patterns
│
├── 🚀 Installation & Setup
│   ├── setup_linux.sh                   # Automated installer
│   ├── README_LINUX.md                  # Main documentation
│   └── LINUX_MIGRATION_SUMMARY.md       # Migration guide
│
├── ⚙️ Systemd Integration
│   ├── filefinder.service               # Service unit file
│   ├── filefinder.timer                 # Timer unit file
│   └── SYSTEMD_SETUP.md                 # Service setup guide
│
└── 🗄️ Database Scripts
    └── SQLScripts/
        ├── 1mysql_user.sql
        ├── 2rec_files.sql
        ├── 3_rec_performance_indexes.sql
        ├── COMPLETE_DB_EXPORT.sql
        └── DEPLOYMENT_README.md
```

---

## 🔧 Key Linux Adaptations

### 1. **File Ownership** 👤
```python
# Windows: win32security module
# Linux:   pwd + grp modules
owner = "username:groupname"
```

### 2. **Filesystem Navigation** 📂
```python
# Windows: Drive letters (C:\, D:\)
# Linux:   Mount points (/, /home, /mnt)
```

### 3. **System Directories Skipped** 🚫
```python
['/proc', '/sys', '/dev', '/run', '/snap']
```

### 4. **IP Detection** 🌐
```bash
hostname -I  # Primary method
```

### 5. **Logging** 📝
```
/var/log/filefinder/hostname_ip.log
```

---

## 🚀 Quick Start

### Installation

```bash
cd FileFinder_Linux

# Make setup script executable
chmod +x setup_linux.sh

# Run installer
./setup_linux.sh
```

### Database Setup

```bash
# Secure MySQL
sudo mysql_secure_installation

# Create database
mysql -u root -p < SQLScripts/1mysql_user.sql
mysql -u root -p < SQLScripts/2rec_files.sql
mysql -u arungt -p rec_files < SQLScripts/3_rec_performance_indexes.sql
```

### Configuration

```bash
# Edit environment file
nano .env

# Update these values:
MYSQL_HOST=localhost
MYSQL_DATABASE=rec_files
MYSQL_USERNAME=arungt
MYSQL_PASSWORD=your_secure_password
```

### Run Scanner

```bash
# Activate virtual environment
source venv/bin/activate

# Run the scanner
python3 file_info_version_22_linux.py
```

---

## 📊 Scan Options

### File Count Scan
- Counts all files by extension
- Quick overview of filesystem
- No detailed file data

### File Data Scan
- **Full System Scan**: Scans all mount points
- **Specific Path Scan**: Scans chosen directory

---

## ⚙️ Systemd Automation (Optional)

### Install Service

```bash
sudo cp filefinder.service /etc/systemd/system/
sudo cp filefinder.timer /etc/systemd/system/

# Edit paths
sudo nano /etc/systemd/system/filefinder.service

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable filefinder.timer
sudo systemctl start filefinder.timer
```

### Check Status

```bash
sudo systemctl status filefinder.timer
sudo journalctl -u filefinder.service -f
```

---

## 🔒 Security Features

✅ **Sensitive Data Detection**: Configurable patterns (password, creditcard, ssn)  
✅ **Audit Logging**: All scans logged to database  
✅ **File Permissions**: Respects Linux file permissions  
✅ **Secure Credentials**: Environment variables in `.env`

---

## 📈 Performance Features

⚡ **Batch Inserts**: 1000 rows per transaction (configurable)  
⚡ **FK Caching**: In-memory foreign key lookups  
⚡ **Parallel Processing**: Multi-threaded Excel file scanning  
⚡ **Smart Skipping**: System directories auto-excluded

---

## 🆚 Windows vs Linux Comparison

| Feature | Windows | Linux |
|---------|---------|-------|
| **File Owner** | `DOMAIN\Username` | `username:groupname` |
| **Paths** | `C:\Users\...` | `/home/...` |
| **Dependencies** | pywin32, keyboard | pwd, grp |
| **Logging** | Current dir | `/var/log/filefinder` |
| **Automation** | Task Scheduler | systemd timer |
| **Permissions** | Run as Admin | `sudo -E` for full scan |

---

## 📦 Dependencies

### Core Python Packages
- `mysql-connector-python==8.2.0` - Database connectivity
- `pandas==2.1.2` - Data processing
- `psutil==5.9.6` - System information
- `python-dotenv==1.0.0` - Environment variables
- `questionary==2.0.1` - Interactive prompts
- `rich==13.7.0` - Beautiful terminal output
- `loguru==0.7.2` - Advanced logging
- `openpyxl==3.1.2` - Excel file support
- `xlrd==2.0.1` - Legacy Excel support

### System Requirements
- Python 3.11.x (EXACTLY - not 3.12 or higher)
- MySQL 8.0+
- Ubuntu 20.04+ / Debian 11+ / RHEL 8+ / CentOS 8+ / Fedora 35+

---

## 🛠️ Configuration Options (.env)

```bash
# Database
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_DATABASE=rec_files
MYSQL_USERNAME=arungt
MYSQL_PASSWORD=your_password

# File Extensions to Scan
D_FILE_DETAILS_FILE_EXTENSIONS=.xlsx,.xls,.pdf,.doc,.docx,.txt

# Date Filter (0=all, >0=modified in last N days)
N_DAYS=0

# Performance
BATCH_INSERT_SIZE=1000
ENABLE_FK_CACHING=true
EXCEL_PROCESSING_WORKERS=4

# Paths
LOG_DIRECTORY=/var/log/filefinder
TEMP_DIRECTORY=/tmp/filefinder

# Features
ENABLE_FILE_EXT_COUNT_IN_SCAN=false
ENABLE_EXCEL_FILE_DATA_SCAN=false
ENABLE_APP_LOG_TO_DB=true

# Sensitive Data
IS_SENSITIVE_FILE_EXTENSIONS=.xls,.xlsx,.doc,.docx,.pdf
FILE_PATH_SCAN_SENSITIVE_PATTERNS=password,creditcard,ssn,confidential
```

---

## 🐛 Troubleshooting

### Permission Denied
```bash
# Run with sudo for full system scan
sudo -E env PATH=$PATH python3 file_info_version_22_linux.py
```

### MySQL Connection Failed
```bash
# Check MySQL service
sudo systemctl status mysql

# Test connection
mysql -u arungt -p -e "SHOW DATABASES;"
```

### Log Directory Issues
```bash
# Create log directory
sudo mkdir -p /var/log/filefinder
sudo chown $USER:$USER /var/log/filefinder
```

### Python Version
```bash
# Check version
python3 --version  # Must be 3.11+

# Install Python 3.11 on Ubuntu
sudo apt-get update
sudo apt-get install python3.11 python3.11-venv
```

---

## 📚 Documentation Files

1. **README_LINUX.md** - Main Linux documentation
2. **LINUX_MIGRATION_SUMMARY.md** - Migration overview
3. **SYSTEMD_SETUP.md** - Automated scheduling guide
4. **SQLScripts/DEPLOYMENT_README.md** - Database setup

---

## 🎯 Use Cases

### 1. **Data Compliance Audits**
Scan for sensitive data patterns across servers

### 2. **Storage Management**
Inventory files by type and size

### 3. **Security Assessments**
Identify files with sensitive keywords

### 4. **Backup Planning**
Catalog files by modification date

### 5. **Migration Planning**
Assess data before cloud migration

---

## ✨ Features Preserved from Windows Version

✅ Batch insert optimization  
✅ FK caching for performance  
✅ Excel file content scanning  
✅ Sensitive data detection  
✅ Audit trail logging  
✅ Database or .env configuration  
✅ File extension filtering  
✅ Date-based filtering  
✅ Automatic retry logic  
✅ Progress logging

---

## 🆕 New Linux-Specific Features

🆕 Systemd service integration  
🆕 Automatic system directory exclusion  
🆕 Mount point detection  
🆕 Linux file ownership (user:group)  
🆕 System-wide logging (/var/log)  
🆕 Multi-user systemd support  
🆕 Native Linux IP detection

---

## 📞 Support

For issues or questions:
- Check log files: `/var/log/filefinder/`
- Review database audit_info table
- Consult README_LINUX.md
- Check systemd logs: `sudo journalctl -u filefinder.service`

---

## 👤 Author

**Arun Kumar**  
Email: arunkg99@gmail.com  
Project: FileFinder Linux v7.0

---

## 📄 License

Copyright © 2024. All rights reserved.

---

## 🎉 Success!

Your Linux FileFinder project is ready to deploy!

**Next Steps:**
1. Transfer the `FileFinder_Linux/` folder to your Linux server
2. Run `./setup_linux.sh`
3. Configure database and `.env`
4. Start scanning!

**Happy File Finding! 🔍**
