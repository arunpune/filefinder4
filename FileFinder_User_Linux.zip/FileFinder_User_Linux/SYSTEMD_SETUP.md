# FileFinder Linux - Systemd Service Setup

This directory contains systemd service and timer files for automating FileFinder scans on Linux.

## Files

- `filefinder.service` - Service unit file for running FileFinder
- `filefinder.timer` - Timer unit file for scheduling scans

## Installation

### 1. Copy Files to Systemd Directory

```bash
sudo cp filefinder.service /etc/systemd/system/
sudo cp filefinder.timer /etc/systemd/system/
```

### 2. Edit Service File

Update the paths in `/etc/systemd/system/filefinder.service`:

```bash
sudo nano /etc/systemd/system/filefinder.service
```

Change:
- `User=` to your username
- `WorkingDirectory=` to your FileFinder installation path
- `ExecStart=` to match your installation path

Example:
```ini
User=arungt
WorkingDirectory=/home/arungt/FileFinder_Linux
ExecStart=/home/arungt/FileFinder_Linux/venv/bin/python3 /home/arungt/FileFinder_Linux/file_info_version_22_linux.py
```

### 3. Reload Systemd

```bash
sudo systemctl daemon-reload
```

### 4. Enable and Start Timer

```bash
# Enable timer to start on boot
sudo systemctl enable filefinder.timer

# Start the timer
sudo systemctl start filefinder.timer
```

## Usage

### Check Timer Status

```bash
sudo systemctl status filefinder.timer
```

### Check Service Status

```bash
sudo systemctl status filefinder.service
```

### View Timer Schedule

```bash
systemctl list-timers --all | grep filefinder
```

### Run Service Manually

```bash
sudo systemctl start filefinder.service
```

### View Logs

```bash
# Service logs
sudo journalctl -u filefinder.service

# Recent logs
sudo journalctl -u filefinder.service -n 50

# Follow logs in real-time
sudo journalctl -u filefinder.service -f
```

## Customizing Schedule

Edit the timer file to change schedule:

```bash
sudo nano /etc/systemd/system/filefinder.timer
```

### Schedule Examples

**Daily at 2 AM:**
```ini
OnCalendar=*-*-* 02:00:00
```

**Weekly on Sunday at 3 AM:**
```ini
OnCalendar=Sun *-*-* 03:00:00
```

**Every 6 hours:**
```ini
OnCalendar=*-*-* 00/6:00:00
```

**Monthly on the 1st at midnight:**
```ini
OnCalendar=*-*-01 00:00:00
```

After editing, reload:
```bash
sudo systemctl daemon-reload
sudo systemctl restart filefinder.timer
```

## Troubleshooting

### Timer Not Running

```bash
# Check if timer is enabled
systemctl is-enabled filefinder.timer

# Enable if not
sudo systemctl enable filefinder.timer
```

### Service Fails

```bash
# Check logs for errors
sudo journalctl -u filefinder.service -n 100

# Test service manually
sudo systemctl start filefinder.service
sudo systemctl status filefinder.service
```

### Permission Issues

Ensure the user specified in the service file has:
- Read access to FileFinder directory
- Write access to `/var/log/filefinder`
- MySQL database access

```bash
# Set permissions
sudo chown -R arungt:arungt /opt/filefinder
sudo chown -R arungt:arungt /var/log/filefinder
```

## Disable Scheduled Scans

```bash
# Stop and disable timer
sudo systemctl stop filefinder.timer
sudo systemctl disable filefinder.timer
```

## Remove Service

```bash
# Stop and disable
sudo systemctl stop filefinder.timer
sudo systemctl disable filefinder.timer

# Remove files
sudo rm /etc/systemd/system/filefinder.service
sudo rm /etc/systemd/system/filefinder.timer

# Reload
sudo systemctl daemon-reload
```
