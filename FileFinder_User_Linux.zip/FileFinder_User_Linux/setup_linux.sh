#!/bin/bash
# FileFinder Linux Setup Script

echo "========================================="
echo "FileFinder Linux Installation Script"
echo "========================================="

# Check if running as root for MySQL setup
if [ "$EUID" -ne 0 ]; then 
   echo "Note: Some operations may require sudo privileges"
fi

# Check Python version
echo "Checking Python version..."
if ! command -v python3.11 &> /dev/null; then
    echo "ERROR: Python 3.11 is required and not found."
    echo "Install with: sudo apt-get install python3.11 python3.11-venv"
    exit 1
fi

PYTHON_VERSION=$(python3.11 --version 2>&1 | awk '{print $2}')
echo "✓ Python version: $PYTHON_VERSION"

echo "✓ Python version: $PYTHON_VERSION"

# Check MySQL
echo "Checking MySQL installation..."
if ! command -v mysql &> /dev/null; then
    echo "WARNING: MySQL not found. Install with:"
    echo "  sudo apt-get update"
    echo "  sudo apt-get install mysql-server"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "✓ MySQL installed"
fi

# Create virtual environment with Python 3.11
echo "Creating virtual environment..."
python3.11 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "Installing dependencies..."
pip install wheel setuptools
pip install "numpy<2.0"
pip install pandas==2.1.2
pip install -r requirements-linux.txt

# Create log directory
echo "Creating log directory..."
sudo mkdir -p /var/log/filefinder
sudo chown $USER:$USER /var/log/filefinder
echo "✓ Log directory created: /var/log/filefinder"

# Create temp directory
echo "Creating temp directory..."
mkdir -p /tmp/filefinder
echo "✓ Temp directory created: /tmp/filefinder"

echo ""
echo "========================================="
echo "Installation complete!"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Configure MySQL: sudo mysql_secure_installation"
echo "2. Create database: mysql -u root -p < SQLScripts/2rec_files.sql"
echo "3. Update .env file with your settings"
echo "4. Run: source venv/bin/activate && python3 file_info_version_22_linux.py"
echo ""
