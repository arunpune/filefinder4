# FileFinder Deployment Architecture

## Two-Folder Structure

This project has been separated into **two deployment packages** for distributed architecture:

```
filefinder4/
├── FileFinder_User_Linux/          ← Linux Scanner Clients
│   └── README_USER.md             (Start here for Linux)
│
└── FileFinder_Server_Windows/      ← Windows Database Server
    └── README_SERVER.md           (Start here for Windows)
```

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                    WINDOWS SERVER (Device 2)                     │
│  FileFinder_Server_Windows/                                      │
│                                                                  │
│  • MySQL 8.0+ Database                                          │
│  • Database: rec_files                                          │
│  • User: arungt / fi!ef!ndgt!23                                 │
│  • Port: 3306 (open to network)                                 │
│  • Stores ALL scan data centrally                               │
│                                                                  │
│  Files:                                                          │
│  - SQLScripts/ (database creation)                              │
│  - setup_server.bat (automated setup)                           │
│  - README_SERVER.md (setup guide)                               │
│  - WINDOWS_FIREWALL_SETUP.md (network config)                   │
└──────────────────────────────────────────────────────────────────┘
                              ▲
                              │ MySQL Protocol
                              │ TCP Port 3306
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        │                     │                     │
┌───────▼──────┐     ┌────────▼──────┐     ┌───────▼──────┐
│ Linux Client │     │ Linux Client  │     │ Linux Client │
│   (Kali)     │     │  (Ubuntu)     │     │  (Debian)    │
│              │     │               │     │              │
│ FileFinder_  │     │ FileFinder_   │     │ FileFinder_  │
│ User_Linux/  │     │ User_Linux/   │     │ User_Linux/  │
│              │     │               │     │              │
│ • Scans      │     │ • Scans       │     │ • Scans      │
│   local      │     │   local       │     │   local      │
│   files      │     │   files       │     │   files      │
│ • Sends to   │     │ • Sends to    │     │ • Sends to   │
│   server     │     │   server      │     │   server     │
│ • Python 3.11│     │ • Python 3.11 │     │ • Python 3.11│
└──────────────┘     └───────────────┘     └──────────────┘
```

---

## Deployment Workflow

### Step 1: Setup Windows Server (Once)

**On Windows machine (Device 2):**

1. Navigate to server folder:
   ```cmd
   cd filefinder4\FileFinder_Server_Windows
   ```

2. Read setup guide:
   ```cmd
   type README_SERVER.md
   ```

3. Run automated setup:
   ```cmd
   setup_server.bat
   ```

4. Configure firewall (if remote access needed):
   - See `WINDOWS_FIREWALL_SETUP.md`
   - Open port 3306 for MySQL

5. Verify database is running and accessible

**Result:** Windows server is ready to receive scan data from Linux clients

---

### Step 2: Deploy Linux Scanners (Repeat per machine)

**On each Linux machine (Device 1, Device 3, etc.):**

1. Copy `FileFinder_User_Linux/` folder to Linux machine:
   ```bash
   # Example: Copy from Windows share or USB
   scp -r FileFinder_User_Linux/ user@linux-machine:~/
   ```

2. Navigate to folder:
   ```bash
   cd ~/FileFinder_User_Linux
   ```

3. Read setup guide:
   ```bash
   cat README_USER.md
   ```

4. Install Python 3.11:
   ```bash
   sudo apt install python3.11 python3.11-venv -y
   ```

5. Run installation:
   ```bash
   chmod +x setup_linux.sh
   ./setup_linux.sh
   ```

6. Configure `.env` with Windows server IP:
   ```bash
   nano .env
   ```
   
   Update:
   ```
   MYSQL_HOST=192.168.1.50  # ← Your Windows IP
   ```

7. Test connection:
   ```bash
   mysql -h 192.168.1.50 -u arungt -p
   # Password: fi!ef!ndgt!23
   ```

8. Run first scan:
   ```bash
   source venv/bin/activate
   python file_info_version_22_linux.py
   ```

**Result:** Linux scanner sends data to Windows MySQL server

---

## Key Differences Between Folders

### FileFinder_User_Linux/ (Client)

**Purpose:** Scan local Linux filesystem and send to server

**Contains:**
- ✅ Python scanner code
- ✅ Linux-specific adaptations
- ✅ Installation scripts
- ✅ Configuration templates
- ✅ Documentation
- ✅ SQL scripts (for reference only)
- ❌ No database hosting
- ❌ No server setup

**Requirements:**
- Python 3.11 ONLY
- Network access to Windows server
- Linux OS (Kali, Ubuntu, Debian, etc.)

**Actions:**
- Scans files
- Collects metadata
- Sends to MySQL server
- Stores logs locally

---

### FileFinder_Server_Windows/ (Server)

**Purpose:** Host central MySQL database for all scans

**Contains:**
- ✅ SQL database scripts
- ✅ Windows setup automation
- ✅ Firewall configuration guides
- ✅ Server documentation
- ❌ No Python scanner code
- ❌ No file scanning capability

**Requirements:**
- Windows OS (Server, 10, 11)
- MySQL 8.0+
- Network accessibility (port 3306)
- Administrator access

**Actions:**
- Hosts MySQL database
- Stores all scan data
- Provides query interface
- Centralizes reporting

---

## Credentials (Same for All)

**DO NOT CHANGE THESE - They are consistent across deployment:**

```
Database: rec_files
Username: arungt
Password: fi!ef!ndgt!23
Port:     3306
```

All Linux clients use these credentials to connect to Windows server.

---

## Network Requirements

### Firewall Rules

**Windows Server:**
- Allow **inbound** TCP port 3306
- From specific IPs (recommended) or all (0.0.0.0/0)

**Linux Clients:**
- Allow **outbound** TCP port 3306
- Usually allowed by default

### IP Configuration

**Windows Server:**
1. Note IP address:
   ```cmd
   ipconfig
   ```
   Example: `192.168.1.50`

2. Ensure static IP or DHCP reservation

**Linux Clients:**
1. Update `.env` with server IP:
   ```
   MYSQL_HOST=192.168.1.50
   ```

2. Test connectivity:
   ```bash
   ping 192.168.1.50
   nc -zv 192.168.1.50 3306
   ```

---

## Scalability

### Adding More Linux Scanners

1. Copy `FileFinder_User_Linux/` to new machine
2. Run `setup_linux.sh`
3. Configure `.env` with same Windows server IP
4. Run scanner

**Each machine will:**
- Appear as separate hostname in database
- Send data to same central server
- Be queryable from Windows

### Query All Machines

**On Windows server:**
```sql
USE rec_files;

-- See all machines that have scanned
SELECT DISTINCT hostname, ip_address, os_type
FROM f_machine_files_summary_count;

-- Total files across all machines
SELECT SUM(total_n_files) AS total_files_all_machines
FROM f_machine_files_summary_count;

-- Files by machine
SELECT hostname, COUNT(*) AS file_count
FROM d_file_details
GROUP BY hostname;
```

---

## Documentation Quick Reference

### For Linux Users (Scanning)

| Document | Purpose |
|----------|---------|
| `README_USER.md` | Main Linux client guide |
| `DEPLOYMENT_CHECKLIST.md` | Step-by-step deployment |
| `README_LINUX.md` | Complete Linux documentation |
| `PROJECT_OVERVIEW.md` | Full project overview |
| `SYSTEMD_SETUP.md` | Automation setup |

**Start with:** `README_USER.md`

### For Windows Admin (Database)

| Document | Purpose |
|----------|---------|
| `README_SERVER.md` | Main Windows server guide |
| `WINDOWS_FIREWALL_SETUP.md` | Network configuration |
| `SQLScripts/DEPLOYMENT_README.md` | Database deployment |

**Start with:** `README_SERVER.md`

---

## Python Version Requirements

**CRITICAL:** This project requires **Python 3.11 ONLY**

- ✅ Python 3.11.0
- ✅ Python 3.11.1
- ✅ Python 3.11.9
- ❌ Python 3.12.x (NOT supported)
- ❌ Python 3.10.x (NOT supported)
- ❌ Python 3.13+ (NOT supported)

**Why?** Dependencies and code are locked to 3.11 minor versions.

**Linux installation:**
```bash
sudo apt install python3.11 python3.11-venv -y
python3.11 --version  # Should show 3.11.x
```

---

## Common Deployment Scenarios

### Scenario 1: Single Linux → Single Windows

```
Linux Kali (192.168.1.100) → Windows Server (192.168.1.50)
```

**Setup:**
1. Deploy server on Windows (192.168.1.50)
2. Deploy client on Linux
3. Configure `.env`: `MYSQL_HOST=192.168.1.50`
4. Run scan

---

### Scenario 2: Multiple Linux → Single Windows

```
Linux-1 (192.168.1.100) ──┐
Linux-2 (192.168.1.101) ──┼→ Windows Server (192.168.1.50)
Linux-3 (192.168.1.102) ──┘
```

**Setup:**
1. Deploy server once on Windows
2. Deploy client on each Linux (same folder copied 3 times)
3. All `.env` files point to same `MYSQL_HOST=192.168.1.50`
4. Each runs scans independently
5. All data centralized on Windows

---

### Scenario 3: Cross-Network (VPN/Internet)

```
Linux Remote (10.0.0.5 via VPN) → Windows Server (192.168.1.50)
```

**Setup:**
1. Setup VPN between networks
2. Or use static public IP with firewall restrictions
3. Configure `.env`: `MYSQL_HOST=<VPN-IP or Public-IP>`
4. Ensure port 3306 allowed through VPN/router

**Security:** Use VPN; avoid exposing MySQL to internet

---

## Troubleshooting Connection Issues

### Test from Linux to Windows

```bash
# Step 1: Ping
ping 192.168.1.50

# Step 2: Check port
nc -zv 192.168.1.50 3306

# Step 3: Test MySQL
mysql -h 192.168.1.50 -u arungt -p
# Enter password: fi!ef!ndgt!23
```

If any fail:
- **Ping fails:** Network/firewall issue
- **Port fails:** MySQL not listening or firewall blocking
- **MySQL fails:** Wrong credentials or user not created

---

## Data Flow

```
Linux Scanner (file_info_version_22_linux.py)
    ↓
Reads .env configuration (MYSQL_HOST=192.168.1.50)
    ↓
Scans local Linux filesystem (/home, /opt, etc.)
    ↓
Collects file metadata (path, size, owner, dates)
    ↓
Connects to MySQL @ 192.168.1.50:3306
    ↓
Inserts batch records to rec_files.d_file_details
    ↓
Updates summary in rec_files.f_machine_files_summary_count
    ↓
Windows MySQL Server stores data permanently
    ↓
Admin can query from Windows MySQL Workbench or CLI
```

---

## Maintenance

### Linux Scanner Updates

To update scanner code on all machines:
1. Modify `file_info_version_22_linux.py`
2. Copy updated file to each Linux machine
3. Restart scans

### Database Schema Updates

To update database structure:
1. Modify SQL scripts in `FileFinder_Server_Windows/SQLScripts/`
2. Run migration script on Windows MySQL
3. Linux clients automatically use new schema

### Credential Changes

If you need to change password:
1. Update on Windows MySQL:
   ```sql
   ALTER USER 'arungt'@'%' IDENTIFIED BY 'newpassword';
   ```
2. Update `.env` on ALL Linux machines:
   ```
   MYSQL_PASSWORD=newpassword
   ```

---

## Support & Contact

- **Email:** arunkg99@gmail.com
- **Documentation Location:** Each folder has its own README
- **SQL Scripts:** `FileFinder_Server_Windows/SQLScripts/`
- **Issues:** Check respective README troubleshooting sections

---

## Summary

- **Windows Server** = Central MySQL database (setup once)
- **Linux Clients** = File scanners (deploy on many machines)
- **Connection** = All Linux → Windows MySQL (port 3306)
- **Credentials** = Same for all (arungt / fi!ef!ndgt!23)
- **Python** = 3.11 ONLY on Linux
- **Data** = Centralized on Windows for querying

**Get Started:**
1. 📁 **Windows**: `cd FileFinder_Server_Windows` → Read `README_SERVER.md`
2. 🐧 **Linux**: `cd FileFinder_User_Linux` → Read `README_USER.md`

---

**Both folders are self-contained deployment packages. All credentials remain unchanged as requested.** ✅
