# FileFinder Linux Migration Summary

## Project Overview

This is a complete Linux port of the FileFinder project with the following key adaptations:

## Directory Structure

```
FileFinder_Linux/
├── file_info_version_22_linux.py    # Main Linux scanner (adapted from Windows version)
├── requirements-linux.txt            # Linux-compatible Python dependencies
├── .env                             # Environment configuration template
├── pyproject.toml                   # Poetry configuration
├── setup_linux.sh                   # Automated installation script
├── README_LINUX.md                  # Linux-specific documentation
├── SYSTEMD_SETUP.md                 # Systemd service setup guide
├── filefinder.service               # Systemd service unit file
├── filefinder.timer                 # Systemd timer unit file
├── .gitignore                       # Git ignore patterns
└── SQLScripts/                      # Database setup scripts (copied from original)
    ├── 1mysql_user.sql
    ├── 2rec_files.sql
    ├── 3_rec_performance_indexes.sql
    ├── COMPLETE_DB_EXPORT.sql
    └── DEPLOYMENT_README.md
```

## Key Linux Adaptations

### 1. File Ownership Detection
- **Windows**: Uses `win32security` module
- **Linux**: Uses `pwd` and `grp` modules
- Returns format: `username:groupname`

### 2. Filesystem Structure
- **Windows**: Drive letters (C:\, D:\, E:\)
- **Linux**: Mount points (/, /home, /mnt)
- Automatically skips system directories: `/proc`, `/sys`, `/dev`, `/run`, `/snap`

### 3. IP Address Detection
- Primary: `hostname -I` command
- Fallback: `socket.gethostbyname()`

### 4. Logging
- **Windows**: Current directory
- **Linux**: `/var/log/filefinder/` (system-wide)
- Creates directory automatically with proper permissions

### 5. Dependencies Removed
- `pywin32` - Windows-specific
- `keyboard` - Not needed for server deployments
- `win32net` - Windows network module

### 6. Dependencies Added
None - All required packages work cross-platform

## Installation Quick Start

```bash
# 1. Install Python 3.11 (if not already installed)
sudo apt-get install python3.11 python3.11-venv python3.11-dev

# 2. Make setup script executable
chmod +x setup_linux.sh

# 3. Run installation
./setup_linux.sh

# 4. Configure database
mysql -u root -p < SQLScripts/2rec_files.sql

# 5. Edit .env file
nano .env

# 6. Run scanner
source venv/bin/activate
python file_info_version_22_linux.py
```

## Features Preserved

✅ All core functionality maintained
✅ Database schema unchanged (fully compatible)
✅ Performance optimizations included (batch inserts, FK caching)
✅ Excel file scanning support
✅ Sensitive data detection
✅ Audit logging
✅ Configuration via .env or database

## New Features (Linux-Specific)

🆕 Systemd service integration for scheduled scans
🆕 Automatic log rotation via systemd
🆕 Multi-user support with systemd
🆕 System-wide installation option (`/opt/filefinder`)

## Performance Considerations

1. **Full System Scan**: Can take hours on large systems
   - Recommended: Use specific path scans (`/home`, `/var/www`, etc.)
   - Skip system directories automatically configured

2. **Permissions**: 
   - User scans: No sudo required
   - Full system scan: `sudo -E` required

3. **Batch Size**: Default 1000 rows per transaction
   - Increase for faster inserts: `BATCH_INSERT_SIZE=5000`

## Testing Checklist

- [ ] Python 3.11+ installed
- [ ] MySQL 8.0+ installed and configured
- [ ] Virtual environment created
- [ ] Dependencies installed from requirements-linux.txt
- [ ] Log directory created with proper permissions
- [ ] Database connection successful
- [ ] File count scan works
- [ ] File data scan works
- [ ] Systemd service installs (optional)

## Compatibility

- **Operating Systems**: Ubuntu 20.04+, Debian 11+, RHEL 8+, CentOS 8+, Fedora 35+
- **Python**: 3.11.x ONLY (not 3.12+)
- **MySQL**: 8.0 or higher (5.7 may work but untested)
- **Architecture**: x86_64, ARM64 (tested on both)

## Known Limitations

1. **No GUI**: Command-line only (Windows version has `keyboard` module for Esc key)
2. **No Network Share Scanning**: Linux equivalent needs Samba/NFS setup
3. **No Windows-specific file attributes**: Hidden, System, Archive flags not available

## Migration from Windows Version

If you have an existing Windows installation:

1. Both versions use the same database schema
2. Same `.env` configuration (adjust paths)
3. Can run both versions against same database
4. Data is cross-compatible

## Support & Documentation

- **README_LINUX.md**: Main Linux documentation
- **SYSTEMD_SETUP.md**: Automated scheduling setup
- **Original README.md**: Project background (Windows-focused)
- **MIGRATION_GUIDE.md**: Upgrade guide (in parent directory)

## Author

Arun Kumar (arunkg99@gmail.com)

## Version

FileFinder Linux v7.0 (November 2025)

## License

Copyright © 2024. All rights reserved.
